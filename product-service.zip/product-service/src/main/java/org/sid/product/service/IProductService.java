package org.sid.product.service;

import org.sid.product.dto.ProductDTO;

public interface IProductService {

     ProductDTO getProductById(Long id);

     ProductDTO getProductByName(String name);

     ProductDTO saveProduct(ProductDTO productDTO) throws Exception;
}
