package org.sid.product.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.sid.product.dto.ProductDTO;
import org.sid.product.entity.Product;

@Mapper
public interface ProductMapper {

    ProductMapper MAPPER = Mappers.getMapper(ProductMapper.class);
    ProductDTO toDto(Product product);
    Product toEntity(ProductDTO productDTO);

}
