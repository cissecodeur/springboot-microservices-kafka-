package org.sid.product.service.impl;

import org.sid.product.dto.ProductDTO;
import org.sid.product.entity.Product;
import org.sid.product.mapper.ProductMapper;
import org.sid.product.repository.ProductRepository;
import org.sid.product.service.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.auditing.CurrentDateTimeProvider;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.Optional;

@Service
public class ProductServiceImpl implements IProductService {

    private final ProductRepository productRepository;

    @Autowired
    public ProductServiceImpl(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    //ici je vais ajouter un produit
    public ProductDTO getProductById(Long id){
         Product product = productRepository.findById(id).orElseThrow(NullPointerException::new);
         return ProductMapper.MAPPER.toDto(product);
    }

    /**
     * @param name
     * @return
     */
    @Override
    public ProductDTO getProductByName(String name) {
        Optional<Product> product = productRepository.findByName(name);
        return ProductMapper.MAPPER.toDto(product.get());
    }

    /**
     * @param productDTO
     * @return productDTO
     */
    @Override
    public ProductDTO saveProduct(ProductDTO productDTO) throws Exception {
        Product product = productRepository.findByName(productDTO.productName())
                                           .orElseThrow(Exception::new);

        Product productToSave = ProductMapper.MAPPER.toEntity(productDTO);
                productToSave.setCreatedAt(LocalDateTime.now());
                productRepository.save(productToSave);
        return ProductMapper.MAPPER.toDto(productToSave);
    }



}
